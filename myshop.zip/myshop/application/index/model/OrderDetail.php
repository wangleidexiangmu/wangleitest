<?php
namespace app\index\model;
use \think\Model;
class OrderDetail extends Model{
    protected $createTime='ctime';
    protected $updateTime=false;
}