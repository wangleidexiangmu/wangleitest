<?php
namespace app\index\model;
use \think\Model;
class History extends Model{
    protected $createTime=false;
    protected $updateTime=false;
}