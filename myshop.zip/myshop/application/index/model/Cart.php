<?php
namespace app\index\model;
use \think\Model;
class Cart extends Model{
    protected $createTime='ctime';
    protected $updateTime='utime';
    //密码修改器
  
    
}