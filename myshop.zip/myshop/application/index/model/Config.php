<?php
namespace app\index\model;
use \think\Model;
class Config extends Model{

}