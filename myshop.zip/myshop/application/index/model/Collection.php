<?php
namespace app\index\model;
use \think\Model;
class Collection extends Model{
    protected $createTime=false;
    protected $updateTime=false;
}