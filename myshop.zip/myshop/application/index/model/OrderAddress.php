<?php
namespace app\index\model;
use \think\Model;
class OrderAddress extends Model{
    protected $createTime='ctime';
    protected $updateTime=false;
}