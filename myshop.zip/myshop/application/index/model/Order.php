<?php
namespace app\index\model;
use \think\Model;
class Order extends Model{
    protected $createTime='ctime';
    protected $updateTime=false;
}