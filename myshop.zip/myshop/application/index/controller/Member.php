<?php
namespace app\index\controller;

class Member extends Common
{
    public function member()
    {
        if(checkRequest()){
            $info=input('post.');
            //验证
            $validate=validate('member');
        }else{
            if(!$this->checkUserLogin()){
                $this->error('请先登录',"login/login");exit;
            }else{
                return view();
            }
        }
    }
    public function myOrder(){
        //检测是否登录
        if(!$this->checkUserLogin()){
            $this->error('请先登录',"login/login");exit;
        }
        //获取订单信息
        $where=[
            'user_id'=>$this->getUserId()
        ];
        $order_model=model('Order');
        $orderInfo=collection($order_model->where($where)->select())->toArray();
        $this->assign('orderInfo',$orderInfo);
        return view();
    }
    //订单详情
    public function orderDetail(){
        $order_number=input('get.order_number');
        $data=$this->test($order_number);
    }
    public function test($order_number){
        $showapi_appid = '83198';  //替换此值,在官网的"我的应用"中找到相关值
    $showapi_secret = '551e2c71f9d44d51b713b1e01ca8d024';  //替换此值,在官网的"我的应用"中找到相关值
    $paramArr = array(
    'showapi_appid'=> $showapi_appid,
        'com'=> "zhongtong",
        'nu'=> "73107557759983"
    //添加其他参数
    );

    //创建参数(包括签名的处理)
    function createParam ($paramArr,$showapi_secret) {
    $paraStr = "";
    $signStr = "";
    ksort($paramArr);
    foreach ($paramArr as $key => $val) {
    if ($key != '' && $val != '') {
    $signStr .= $key.$val;
    $paraStr .= $key.'='.urlencode($val).'&';
    }
    }
    $signStr .= $showapi_secret;//排好序的参数加上secret,进行md5
    $sign = strtolower(md5($signStr));
    $paraStr .= 'showapi_sign='.$sign;//将md5后的值作为参数,便于服务器的效验
    
    return $paraStr;
    }

    $param = createParam($paramArr,$showapi_secret);
    $url = 'http://route.showapi.com/64-19?'.$param;
   
    $result = file_get_contents($url);
   
    $result = json_decode($result);
    
  $data=$body=$result->showapi_res_body->data;
   return $data;
    
        }
    }
