<?php
namespace app\index\controller;
use \page\AjaxPage;
class Product extends Common
{
    public function productDetail()
    {
        $this->getCateNav();
        $this->getIndexCateInfo();
        $goods_id=input('get.goods_id',0,'intval');
        if(empty($goods_id)){
            fail('非法操作');
        }
        //查询商品信息
        $where=[
            'goods_id'=>$goods_id
        ];
        $goods=model('goods');
        $goodsInfo=$goods->where($where)->find()->toArray();
        if(empty($goodsInfo)){
            $this->error('此商品不存在，请重新选择');exit;
        }
        if($goodsInfo['goods_up']==2){
            $this->error('此商品已下架');exit;
        }
        $goodsInfo['goods_imgs']=explode('|',ltrim($goodsInfo['goods_imgs'],'|'));
        //print_r($goodsInfo['goods_imgs']);exit;
        $this->getGoodsCateInfo($goodsInfo['cate_id']);
        //历史记录
        if($this->checkUserLogin()){
            //存数据库
            $this->saveHistoryDb($goods_id);
        }else{
            //存cookie
            $this->saveHistoryCookie($goods_id);
        }
        //print_r(unserialize(base64_decode(cookie('history'))));exit;
        $this->assign('goodsInfo',$goodsInfo);
        return view();
    }
    //商品上级分类查询
    public function getGoodsCateInfo($cate_id){
        $cate=model('category');
        $cateWhere=[
            'cate_show'=>1
        ];
        $cateInfo=collection(model('category')->where($cateWhere)->select())->toArray();
        $info=getGoodsCateInfo($cateInfo,$cate_id);
        return $this->assign('goodsCateInfo',$info);
    }
    //历史记录存数据库
    public function saveHistoryDb($goods_id){
        $history=model('history');
        $arr=[
            'user_id'=>$this->getUserId(),
            'goods_id'=>$goods_id,
            'ctime'=>time()
        ];
        $history->save($arr);
    }
    //历史记录存cookie
    public function saveHistoryCookie($goods_id){
        $now=time();
        $prevhistory=cookie('history');
        if(!empty($prevhistory)){
            //解开2维数组
            $history=unserialize(base64_decode($prevhistory));
        }
        //加入本次数据
        $history[]=[
            'goods_id'=>$goods_id,
            'ctime'=>$now,
        ];
        $str=base64_encode(serialize($history));
        cookie('history',$str);
    }

    //浏览记录展示
    public function getHistoryInfo(){
        $goods=model('goods');
        if($this->checkUserLogin()){
            $history = model('history');
            $where = [
                'user_id' => $this->getUserId(),
            ];
            $goods_id=$history->where($where)->order('ctime','desc')->column('goods_id');
            $goods_id=array_slice(array_unique($goods_id),0,5);
            if(!empty($goods_id)){
                foreach ($goods_id as $k => $v) {
                    $historyInfo[] = $goods->where(['goods_id' => $v])->find()->toArray();
                }
                if(!empty($historyInfo)){
                    return $this->assign('historyInfo', $historyInfo);
    
                }
            }
        }else{
            $cookie=cookie('history');

            //echo $cookie;
            if(!empty($cookie)) {
               $arr=array_reverse(unserialize(base64_decode($cookie)));
               $info=[];
              
                foreach ($arr as $k => $v) {
                    if(empty($info[$v['goods_id']])){
                        $info[$v['goods_id']]=$v;
                        $historyInfo[] = $goods->where(['goods_id' => $v['goods_id']])->find()->toArray();
                    }
                   
                }
                if(!empty($historyInfo)){
                    $historyInfo=array_slice($historyInfo,0,5);
                    return $this->assign('historyInfo', $historyInfo);
    
                }
               
            }
        }
       

        
    }
    //全部商品展示
    public function productList(){
        //左侧及导航分类展示数据
        $this->getCateNav(); 
        $this->getIndexCateInfo();
        //查询所有品牌
        $cate=model('category');
        $brand=model('brand');
        $goods=model('goods');
        $cate_id=input('get.cate_id',0,'intval');
        if(empty($cate_id)){
            $where=[
                'goods_up'=>1
            ];
            cookie('cate_id',null);
        }else{
            $cateInfo=$cate->where(['cate_show'=>1])->select();
            $cateId=getCateId($cateInfo,$cate_id);
            $cate_id=trim(implode(',',$cateId).",".$cate_id,',');
            cookie('cate_id',$cate_id);
            $where=[
                'cate_id'=>['in',$cate_id],
                'goods_up'=>1
            ];
        }
        $brandInfo=$brand
            ->field('distinct(g.brand_id),brand_name')
            ->alias('b')
            ->join('shop_goods g','b.brand_id=g.brand_id')
            ->where($where)
            ->select();
        //dump($brandInfo);exit;
        //获得价格区间
        $maxPrice=$goods->where($where)->value("max(goods_selfprice)");
        //echo $maxPrice;
        $priceInfo=$this->getPriceArea($maxPrice);
        //获得商品数据
        $page=1;
        $page_num=20;
        $goodsInfo=$goods
            ->where($where)
            ->order('sale_num','desc')
            ->page($page,$page_num)
            ->select();
        //调用分类页 获取页码
        $count=$goods->where($where)->count();
        $page_str=AjaxPage::ajaxpager($page,$count,$page_num,url('product/productsearch'),'pages');
        //浏览记录展示
        $this->getHistoryInfo();
        //传数据
        $this->assign('brandInfo',$brandInfo);
        $this->assign('priceInfo',$priceInfo);
        $this->assign('goodsInfo',$goodsInfo);
        $this->assign('page_str',$page_str);
        $this->assign('count',$count);
        return view();
    }
    //查询价格区间
    public function getPriceArea($maxPrice){
        $price=[];
        for($i=0;$i<6;$i++){
            $start=$maxPrice/7*$i;
            //echo $start;
            $end=$maxPrice/7*($i+1)-0.01;
            $price[]=number_format($start,2,'.',',').'-'.number_format($end,2,'.',',');
        }
        //$end=$end+0.01;
        $price[]=number_format($end+0.01,2,'.',',').'以上';
        return $price;
    }
    //点击品牌ajax替换价格区间
    public function getPrice(){
        $brand_id=input('post.brand_id',0,'intval');
        //echo $brand_id;exit;
        $goods=model('goods');
        $where['goods_up']=1;
        if(!empty($brand_id)){
            $where['brand_id']=$brand_id;
        }
        $maxPrice=$goods->where($where)->value("max(goods_selfprice)");
        //echo $goods->getLastSql();exit;
        //echo $maxPrice;
        if(!empty($maxPrice)){
            $priceInfo=$this->getPriceArea($maxPrice);
            //dump($priceInfo);
            echo json_encode($priceInfo);
        }else{
            fail('此品牌下没有商品');
        }
    }
    //ajax 分页+搜索商品信息查询
    public function getGoodsInfo(){
        //接收页码+条件
        $page=input('post.p','');
        $brand_id=input('post.brand_id','');
        $price_area=input('post.price_area','');
        $flag=input('post.flag','');
        $order=input('post.order','desc');
        $cate_id=cookie('cate_id');
        //echo $price_area;exit;
        //处理条件
        $where=[];
        if(!empty($cate_id)){
            $where['cate_id']=['in',$cate_id];
        }
        if(!empty($brand_id)){
            $where['brand_id']=$brand_id;
        }
        if(!empty($price_area)){
            $price_area=str_replace(',', '', $price_area);
            if(substr_count($price_area,'-')>0){
                $arr=explode('-',$price_area);
                $where['goods_selfprice']=['between',$arr];
            }else{
                $str=substr($price_area,0,strpos($price_area,'.')+3);
                //echo $str;
                $where['goods_selfprice']=['>=',$str];
            }
        }
        $field='sale_num';
        if($flag==2){
            $field='sale_num';
        }else if($flag==3){
            $field='goods_selfprice';
        }else if($flag==4){
            $where['goods_new']=1;
        }
        //print_r($where);exit;
        //获得商品数据
        $goods=model('goods');
        $page_num=20;
        $goodsInfo=$goods
            ->where($where)
            ->order($field,$order)
            ->page($page,$page_num)
            ->select();
        //echo $goods->getLastsql();exit;
        if(!empty($goodsInfo)){
            //调用分类页 获取页码
            $count=$goods->where($where)->count();
            //echo $count;exit;
            $page_str=AjaxPage::ajaxpager($page,$count,$page_num,url('product/productsearch'),'pages');
            //查询浏览历史记录
           
            $this->assign('goodsInfo',$goodsInfo);
            $this->assign('count',$count);
            $this->assign('page_str',$page_str);
            $this->view->engine->layout(false);
            echo  $this->fetch('div');
        }else{
            echo 'no';
        }
    }
    //
}
