<?php
namespace app\index\controller;
class Index extends Common
{
    public function index()
    { 
        $this->getCateNav();
        $this->getIndexCateInfo();
        $info=$this->getFloorInfo(1);
        $this->assign('info',$info);
        return view();
    }
    //查询楼层数据
    public function getFloorInfo($cate_id){
        $cate=model('category');
        //顶级分类
        $info=[];
        $oneWhere=[
            'cate_id'=>$cate_id,
            'cate_show'=>1
        ];
        $info['oneData']=$cate->field('cate_id,cate_name')->where($oneWhere)->find();
        //二级分类
        $twoWhere=[
            'pid'=>$cate_id,
            'cate_show'=>1
        ];
        $info['twoData']=$cate->field('cate_id,cate_name')->where($twoWhere)->select();
        //商品
        $cateInfo=$cate->where(['cate_show'=>1])->select();
        $cateId=getCateId($cateInfo,$cate_id);
        $cateId=implode(',',$cateId);
        //echo $cateId;
        $goodsWhere=[
            'cate_id'=>['in',$cateId],
            'goods_up'=>1
        ];
        $goods=model('goods');
        $info['goodsData']=$goods->field('goods_id,goods_name,goods_selfprice,goods_img,goods_score')->where($goodsWhere)->select();;
        return $info;
    }
    //更多楼层数据
    public function moreFloor(){
        $cate_id=input('post.cate_id');
        $floor_num=input('post.floor_num')+1;
        $cate=model('category');
        $where=[
            'cate_id'=>['gt',$cate_id],
            'pid'=>0,
            'cate_navshow'=>1
        ];
        $cate_id=$cate->field('cate_id')->where($where)->order('cate_id','asc')->find();
        $cate_id=$cate_id['cate_id'];
        if(!empty($cate_id)){
            $info=$this->getFloorInfo($cate_id);
            //print_r($info);exit;
            $this->assign('info',$info);
            //dump($info);exit;
            $this->assign('floor_num',$floor_num);
            //关闭layout
            $this->view->engine->layout(false);
            echo  $this->fetch('div');
        }

    }
}
