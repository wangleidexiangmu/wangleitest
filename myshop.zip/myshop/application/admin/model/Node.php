<?php
namespace app\admin\model;
use \think\Model;
class Node extends Model{
    protected $table='shop_node';
    public function getNodeInfo(){
        $nodeInfo=collection($this->where(['pid'=>0])->select())->toArray();
        foreach($nodeInfo as $k=>$v){
            $where=[
                'pid'=>$v['node_id']
            ];
            $nodeInfo[$k]['son']=collection($this->where($where)->select())->toArray();
        }
        return $nodeInfo;
    }
}