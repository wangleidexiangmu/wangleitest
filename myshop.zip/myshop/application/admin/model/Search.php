<?php
namespace app\admin\model;
use \think\Model;
class Search extends Model
{
    //开启时间戳
    //protected $autoWriteTimestamp = true;
    //定义字段名
    protected $createTime = false;
    protected $updateTime = false;
}