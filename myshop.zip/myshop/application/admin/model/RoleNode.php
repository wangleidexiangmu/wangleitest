<?php
namespace app\admin\model;
use \think\Model;
class RoleNode extends Model{
     
    protected $updateTime = false;
    protected $createTime = false;
}