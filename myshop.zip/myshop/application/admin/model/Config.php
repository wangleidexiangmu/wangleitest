<?php
namespace app\admin\model;
use \think\Model;
class Config extends Model{
    protected $createTime = false;
    protected $updateTime = false;

}