<?php
namespace app\admin\model;
use \think\Model;
class Role extends Model{
     
    protected $table ='shop_role';
    protected $updateTime = false;
    protected $createTime = false;
}