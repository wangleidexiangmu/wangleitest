<?php
namespace app\admin\model;
use \think\Model;
class Friend extends Model
{
    //开启时间戳
    //protected $autoWriteTimestamp = true;
    //定义字段名
    //protected $createTime = 'create_time';
    protected $updateTime = false;
}