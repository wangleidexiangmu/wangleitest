<?php
namespace app\admin\controller;
use \think\Controller;
use think\Db;
class Role extends Controller{
   public function roleadd(){
    if(checkRequest()){
        $data=input('post.');
        Db::startTrans();
        //echo $role_name;exit;
        //角色
        $role=model('role');
        
       $res1=$role->allowField(true)->save($data);
      $role_id=$role->role_id;
      foreach($data['node_id'] as $k=>$v){
          $info[]=['role_id'=>$role_id,'node_id'=>$v];
      }
      $model=model('RoleNode');
      $res2=$model->saveAll($info);
      if($res1&&$res2){
        Db::commit();
        echo '提交';
      }else{
          Db::rollback();
          echo '回滚';
      }
    }else{
        //查询节点
        $node=model('node');
        $data=collection($node->select())->toArray();
        //print_r($data);exit;
        $nodeInfo=getNodeInfo($data);
        $this->assign('nodeInfo',$nodeInfo);
        return view();
    }
}
}