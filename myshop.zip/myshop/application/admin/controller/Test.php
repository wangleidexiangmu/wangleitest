<?php
namespace app\admin\Controller;
class Test extends Common{
    public function test(){
        if(checkRequest()){
            $search=input('post.search');
            $data=[
                'search'=>$search
            ];
            if(empty($search)){
                return '搜索内容不能为空';
            }
            $model=model('search');
            $res=$model->save($data);
            if($res){
                return '搜索成功';
            }else{
                return '搜索失败';
            }
        }else {
            $this->view->engine->layout(false);
            return view();
        }
    }
    public function searchList(){
        $search=input('post.search');
        $where=[
            'search'=>['like',"%$search%"]
        ];
        $model=model('search');
        $info=$model->where($where)->distinct(true)->field('search')->order('id','desc')->limit(10)->select();
        echo json_encode($info);
    }
}