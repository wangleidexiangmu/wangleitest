<?php
namespace app\admin\controller;
class Goods extends Common
{
    public function goodsAdd()
    {
        if(checkRequest()){
            $data=input('post.');
            //验证
            $validate=validate('goods');
            $result=$validate->scene('add')->check($data);
            if(!$result){
                $font=$validate->getError();
                fail($font);
            }
            //保存到数据库
            $model=model('goods');
            $res=$model->allowField(true)->save($data);
            if($res){
                successly('添加成功');
            }else{
                fail('添加失败');
            }
        }else{
            //品牌下拉
            $model=model('brand');
            $where=[
                'is_show'=>1
            ];
            $brandInfo=$model->where($where)->select();
            //分类下拉
            $cateInfo=$this->getCateInfo();
            $this->assign('brandInfo',$brandInfo);
            $this->assign('cateInfo',$cateInfo);
            return view();
        }

    }
    //递归展示
    public function getCateInfo(){
        $model=model('Category');
        $data=collection($model->select())->toArray();
        //dump($data);
        $data=getCateInfo($data);
        return $data;
    }
    //图片上传
    public function goodsUpload(){
        $type=input('get.type');
        $dir=$type==1?'goodsimg':'goodsimgs';
        $this->uploadInfo($dir);
    }
    //图片信息获取
    public function uploadInfo($dir){
        // 获取表单上传文件 例如上传了001.jpg
        $file = request()->file('file');
        // 移动到框架应用根目录/public/uploads/ 目录下
        $info = $file->move(ROOT_PATH . 'public' . DS . "uploads/$dir");
        if($info){
            $arr=[
                'code'=>1,
                'font'=>'添加成功',
                'src'=>$info->getSaveName()
            ];
            echo json_encode($arr);
        }else{
            // 上传失败获取错误信息
            fail($file->getError());
        }
    }
    //富文本编辑器文件上传
    public function goodsSetditImg(){
        // 获取表单上传文件 例如上传了001.jpg
        $file = request()->file('file');
        // 移动到框架应用根目录/public/uploads/ 目录下
        $info = $file->move(ROOT_PATH . 'public' . DS . "uploads/editimg");
        if($info){
            $arr=[
                'code'=>0,
                'font'=>'添加成功',
                'data'=>[
                    'src'=>"http://www.myshop.com/public/uploads/editimg/".$info->getSaveName(),
                    'title'=>'aaa'
                ]
            ];
            echo json_encode($arr);
        }else{
            // 上传失败获取错误信息
            fail($file->getError());
        }
    }
    //商品名称唯一性验证
    public function checkName(){
        $type=input('post.type');
        $goods_name=input('post.goods_name');
        //echo $brand_name;exit;
        if($type==1){
            $where=[
                'goods_name'=>$goods_name
            ];
        }else{
            $goods_id=input('post.goods_id');
            $where=[
                'goods_id'=>['neq',$goods_id],
                'goods_name'=>$goods_name
            ];
        }

        $model=model('Goods');
        $arr=$model->where($where)->find();
        if($arr){
            echo 'no';
        }else{
            echo 'ok';
        }
    }
    //展示页面
    public function goodsList()
    {
        //品牌下拉
        $model=model('brand');
        $where=[
            'is_show'=>1
        ];
        $brandInfo=$model->where($where)->select();
        //分类下拉
        $cateInfo=$this->getCateInfo();
        $this->assign('brandInfo',$brandInfo);
        $this->assign('cateInfo',$cateInfo);
        return view();
    }
    //列表展示
    public function getGoodsInfo(){
        $page=input('get.page');
        $limit=input('get.limit');
        $goods_name=input('get.goods_name');
        $cate_name=input('get.cate_name');
        $brand_name=input('get.brand_name');
        $where=[];
        if(!empty($goods_name)){
            $where['goods_name']=['like',"%$goods_name%"];
        }
        if(!empty($cate_name)){
            $where['cate_name']=$cate_name;
        }
        if(!empty($brand_name)){
            $where['brand_name']=$brand_name;
        }
        $goods=model('goods');
        $count=$goods->getGoodsCount($where);
        $page_count=ceil($count/$limit);
        if($page>$page_count&&$page!=1){
            $page=$page_count;
        }
        $data=$goods->getGoodsInfo($page,$limit,$where);
        return [
            'code'=>0,
            'msg'=>'',
            'count'=>$count,
            'data'=>$data
        ];
    }
    //即删即改
    public function goodsUpdateField(){
        //接收数据
        $data=input('post.');
        //dump($data);
        $info=[$data['field']=>$data['value']];
        //验证
        $validate=validate('goods');
        $res=$validate->scene($data['field'])->check($info);
        if(!$res){
            fail($validate->getError());
        }
        //修改
        $goods=model('goods');
        $where=[
            'goods_id'=>$data['goods_id']
        ];
        $result=$goods->save($info,$where);
        if($result){
            successly('ok');
        }else{
            fail('no');
        }
    }
    //删除
    public function goodsDel(){
        $goods_id=input('post.goods_id');
        $where=[
            'goods_id'=>$goods_id
        ];
        $goods=model('goods');
        $res=$goods->where($where)->delete();
        if($res){
            successly('删除成功');
        }else{
            fail('删除失败');
        }
    }
    //修改
    public function goodsUpdate(){
        if(checkRequest()){
            $data=input('post.');
            if(empty($data['goods_new'])){
                $data['goods_new']=2;
            }
            if(empty($data['goods_best'])){
                $data['goods_best']=2;
            }
            if(empty($data['goods_hot'])){
                $data['goods_hot']=2;
            }
            //验证器
            $validate=validate('goods');
            $result=$validate->scene('add')->check($data);
            if(!$result){
                $font=$validate->getError();
                fail($font);
            }
            //修改数据
            $where=[
                'goods_id'=>$data['goods_id']
            ];
            $model=model('goods');
            $res=$model->allowField(true)->save($data,$where);
            if($res===false){
                fail('修改失败');
            }else{
                successly('修改成功');
            }
        }else {
            //品牌下拉
            $model=model('brand');
            $where=[
                'is_show'=>1
            ];
            $brandInfo=$model->where($where)->select();
            //分类下拉
            $cateInfo=$this->getCateInfo();
            $this->assign('brandInfo',$brandInfo);
            $this->assign('cateInfo',$cateInfo);
            //查询单条数据
            $goods_id = input('get.goods_id');
            $where = [
                'goods_id' => $goods_id
            ];
            $goods = model('goods');
            $data = $goods->where($where)->find();
            $this->assign('data', $data);
            return view();
        }
    }
}