<?php
namespace app\admin\controller;
//use \think\Controller;
class Index extends Common
{
    public function index()
    {
        //dump(session('adminInfo'));exit;
        return view();
    }
}
