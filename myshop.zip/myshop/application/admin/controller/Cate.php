<?php
namespace app\admin\controller;
use \think\Controller;
class Cate extends Controller{
    public function cateList(){
        $data=model('Cate')->query("SELECT *,CONCAT(path,'-',cate_id) as new_path FROM `shop_cate` order by new_path asc");
        $this->assign('data',$data);
        return view();
    }
}