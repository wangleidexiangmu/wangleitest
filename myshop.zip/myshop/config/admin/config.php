<?php
    return [
        'template' =>  [
            'layout_on'     =>  true,
            'layout_name'   =>  'layout',
        ],
        'default_controller'=>'Login',
        'default_action'=>'login',
    ]

?>
