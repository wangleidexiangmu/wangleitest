<?php

namespace App\model\index;

use Illuminate\Database\Eloquent\Model;

class shop_goods extends Model
{
    protected $table='shop_goods';
}
