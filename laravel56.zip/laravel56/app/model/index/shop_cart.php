<?php

namespace App\model\index;

use Illuminate\Database\Eloquent\Model;

class shop_cart extends Model
{
    protected $table='shop_cart';
}